<?php
/*
Plugin Name: Colio
Plugin URI: http://plugins.gravitysign.com/colio-wp/
Description: With this plugin you will be able to create filterable, multi-column portfolio with the expand & preview feature, that will allow your site visitors to check details about your portfolio items in convenient, user-friendly way.
Version: 1.0
Author: flGravity
Author URI: http://codecanyon.net/user/flGravity
*/


/**
* Globals
*/

define('COLIO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('COLIO_PLUGIN_URL', plugins_url('/colio/'));
define('COLIO_PLUGIN_DOCS', COLIO_PLUGIN_URL . 'docs/');


/**
* Includes
*/

require(COLIO_PLUGIN_DIR . 'includes/options.php');
require(COLIO_PLUGIN_DIR . 'includes/post.php');
require(COLIO_PLUGIN_DIR . 'includes/admin.php');
require(COLIO_PLUGIN_DIR . 'includes/settings.php');


/**
* Function to generate ID from name
*
* @param string $name Name
* @return string Slug
*/

function colio_get_portfolio_id( $name ) {
	$slug = strtolower( $name );
	$slug = preg_replace('/[^a-z0-9_]+/', '_', $slug);
	$slug = preg_replace('/^_|_$/', '', $slug);
	return $slug;
}

/*
* Function to get HTML string of portfolio groups, possibly with number of items
*
* @param array $groups Array with group IDs
* @param bool $items_count Add total number of items in group, default is false
* @return string HTML with groups as links
*/

function colio_get_portfolio_groups( $groups, $items_count = false ){
	if( $groups && is_array($groups) ) {	
		$group_links = array();
		$group_url = 'edit-tags.php?taxonomy=colio_group&post_type=colio_item';
		foreach( $groups as $id) {
			$group = get_term($id, 'colio_group');
			$group_items = get_objects_in_term($group->term_id, 'colio_group', array('order' => 'ASC'));
			$group_total = $items_count ? ' (' . count($group_items) . ')' : '';
			$group_links[] = '<a href="' . $group_url . '">' . esc_html($group->name) . $group_total . '</a>';
		}
		return  implode(', ', $group_links);
	} else {
		return '-';
	}
}


/**
* Function to convert hex color to rgba() value with opacity
*
* @param string $color Hex color as #000 or #000000
* @param float $opacity Opacity 0-1
* @param string $fallback Fallback if $color is incorrect
* @return string Color as "rgba(0,0,0,0)"
*/

function colio_rgba_color($color, $opacity, $fallback = '') {
	// get part after #
	$color = str_replace('#', '', $color);
	
	// check if we have #000 or #000000 hex color
	$color = strtolower( trim($color) );
	
	// how to split hex, by 1 or 2 symbols
	$n = strlen($color) / 3;
	if($n != 1 && $n != 2) {
		return $fallback;
	}
	
	// get channels and return rgba color
	$r = substr($color, 0, $n);
	$g = substr($color, $n, $n);
	$b = substr($color, 2 * $n, $n);
	if($n == 1) {
		$r = $r . $r;
		$g = $g . $g;
		$b = $b . $b;
	}
	
	return "rgba(" . hexdec($r) . "," . hexdec($g) . "," . hexdec($b) . ",$opacity)";
}


/**
* Enable plugin localization
*/

function colio_load_textdomain(){
	load_plugin_textdomain('colio', false, dirname(plugin_basename(__FILE__)) .  '/languages/');
}

add_action('plugins_loaded', 'colio_load_textdomain');


/**
* Define max size for portfolio items (size for 2 column 
* grid with largest screen width)
*/

add_image_size('colio-item-thumb', 460, 300, true);


/**
* Define thumb size for "Extra Photos" metabox uploads
*/

add_image_size('colio-extra-thumb', 150, 150, true);


/**
* Enqueue all frontend scripts & styles for plugin
*/

function colio_plugin_enqueue_scripts(){
	wp_register_script('jquery-easing', COLIO_PLUGIN_URL . 'jquery.easing.1.3.js', array('jquery'), '1.3', true);
	
	wp_enqueue_script('colio', COLIO_PLUGIN_URL . 'jquery.colio.min.js', array('jquery', 'jquery-easing'), '1.1', true);
	wp_enqueue_style('colio', COLIO_PLUGIN_URL . 'colio.css', array(), '1.1');
	
	wp_enqueue_script('isotope', COLIO_PLUGIN_URL . 'jquery.isotope.min.js', array('jquery', 'jquery-easing'), '1.3', true);
	wp_enqueue_style('isotope', COLIO_PLUGIN_URL . 'isotope.css', array(), '1.3');
	
	wp_enqueue_style('colio-grid', COLIO_PLUGIN_URL . 'grid.css', array('colio'), '1.0');
	wp_enqueue_script('colio-init', COLIO_PLUGIN_URL . 'init.js', array('colio','isotope'), '1.0', true);
	
	// link plugin theme files depending which theme is selected
	foreach( colio_list_options() as $id ) {
		$s = colio_get_option($id);
		if( $s['colio']['theme'] == 'black' ) {
			wp_enqueue_style('colio-black', COLIO_PLUGIN_URL . 'colio-black/theme.css', array('colio'), '1.1');
			wp_enqueue_style('fancybox', COLIO_PLUGIN_URL . 'colio-black/fancybox/jquery.fancybox.css', array(), '1.3');
			wp_enqueue_script('fancybox', COLIO_PLUGIN_URL . 'colio-black/fancybox/jquery.fancybox.js', array('jquery'), '1.3', true);
		} else {
			wp_enqueue_style('colio-white', COLIO_PLUGIN_URL . 'colio-white/theme.css', array('colio'), '1.1');
			wp_enqueue_style('flexslider', COLIO_PLUGIN_URL . 'colio-white/flexslider/flexslider.css', array(), '2.2.0');
			wp_enqueue_script('flexslider', COLIO_PLUGIN_URL . 'colio-white/flexslider/jquery.flexslider.js', array('jquery'), '2.2.0', true);
		}
	} 
	
}

add_action('wp_enqueue_scripts', 'colio_plugin_enqueue_scripts');


/**
* Function to export configuration for "Colio jQuery Plugin" as window.colio_options.
* We will use them in init.js file to init plugin.
*/

function colio_export_javascript_options(){
	$data = array();
	
	foreach( colio_list_options() as $id) {
		$s = colio_get_option($id);
		$colio = $s['colio'];
		
		// rename "option_name" keys in array to "optionName"
		foreach( $colio as $key => $value ) {
			if( preg_match_all('/_(\w)/', $key, $match, PREG_SET_ORDER) ) {
				unset($colio[$key]);
				foreach($match as $m) {
					$key = str_replace( $m[0], strtoupper($m[1]), $key );
				}
				$colio[$key] = $value;
			}
		}
		
		// encode array to JSON string
		$data[ $s['_id'] ] = json_encode($colio);
	}
	
	wp_localize_script('colio', 'colio_options', $data);
}

add_action('wp_enqueue_scripts', 'colio_export_javascript_options');


/**
* Function to print custom styles using "wp_head" hook.
*/

function colio_print_custom_styles(){
	if( colio_list_options() ) {
		echo '<style type="text/css">';
		foreach( colio_list_options() as $id ) {
			$s = colio_get_option($id);
			$css_id = '#colio_' . $s['_id'];
			$cvp_id = '#colio_viewport_' . $s['_id'];
			$theme_color = $s['colio']['theme_color'];
			// grid styles
			echo "$css_id .colio-list .colio-inner { margin: 0 {$s['item_margin']}px {$s['item_margin']}px 0; } ";
			echo "$css_id .colio-inner .colio-button { background-color: {$s['item_button_color']}; } ";
			echo "$css_id .colio-inner .colio-view { background-color: " . $s['item_hover_color'] . "; } ";
			echo "$css_id .colio-inner .colio-view { background-color: " . 
			colio_rgba_color( $s['item_hover_color'], $s['item_hover_opacity'], 'initial' ) . "; } ";
			echo "$css_id .colio-summary h4 a { color: {$s['item_title_color']}; } ";
			echo "$css_id .colio-summary h4 a:hover { color: {$s['item_title_hover_color']}; } ";
			echo "$css_id .colio-summary h4 { font-size: {$s['item_title_font_size']}px; } ";
			if( $s['item_title_font'] !== 'inherit') {
				echo "$css_id .colio-summary h4 { font-family: {$s['item_title_font']}, sans-serif; } ";
			}
			echo "$css_id .colio-summary p {color: {$s['item_excerpt_color']}; } "; 
			echo "$css_id .colio-summary p {font-size: {$s['item_excerpt_font_size']}px; } ";
			if( $s['item_excerpt_font'] !== 'inherit') {
				echo "$css_id .colio-summary p {font-family: {$s['item_excerpt_font']}, sans-serif; } ";
			}
			// colio themes (before or after placement)
			echo "$css_id .colio-theme-black a { color: $theme_color; } ";
			echo "$css_id .colio-theme-black .colio-navigation a { background-color: $theme_color; } ";
			echo "$css_id .colio-theme-black .colio-feed li a { background-color: $theme_color; } " ;
			echo "$css_id .colio-theme-white a { color: $theme_color; } ";
			echo "$css_id .colio-theme-white .colio-navigation a { background-color: $theme_color; } ";
			echo "$css_id .colio-theme-white .flex-active { background-color: $theme_color; } ";
			// colio themes (inside placement)
			echo "$cvp_id.colio-theme-black a { color: $theme_color; } ";
			echo "$cvp_id.colio-theme-black .colio-navigation a { background-color: $theme_color; } ";
			echo "$cvp_id.colio-theme-black .colio-feed li a { background-color: $theme_color; } " ;
			echo "$cvp_id.colio-theme-white a { color: $theme_color; } ";
			echo "$cvp_id.colio-theme-white .colio-navigation a { background-color: $theme_color; } ";
			echo "$cvp_id.colio-theme-white .flex-active { background-color: $theme_color; } ";
		}
		echo '</style>';
	}
};

add_action('wp_head', 'colio_print_custom_styles');


/**
* Function to generate HTML for portfolio item. Function 
* must be used inside The Loop
*
* @param array $settings Portfolio settings
* @return string HTML for item
*/

function colio_get_item_html( $settings ){
	global $post;
	
	// get item tags for filtering
	$item_tags = wp_get_post_terms($post->ID, 'colio_tag', 'fields=slugs');
	if( $item_tags && !is_wp_error($item_tags) ) {
		$tags = implode(' ', $item_tags);
	} else {
		$tags = '';
	}
	
	// get excerpt
	$excerpt = $settings['item_excerpt'] ? get_the_excerpt() : '';
		
	// html for item as <LI> element
	$html = '<li data-content="' . esc_attr('#colio_item_' . $post->ID) . '" data-tags="' . $tags . '">' .
				'<div class="colio-inner">' . 
					'<div class="colio-thumb">' . 
						'<div class="colio-view">' .
							'<a class="colio-button colio-link" href="#">' . $settings['item_button_text'] . '</a>' . 
						'</div>' .
						get_the_post_thumbnail($post->ID, 'colio-item-thumb') .
					'</div>' .
					'<div class="colio-summary">' . 
						'<h4><a class="colio-link" href="#">' . get_the_title() . '</a></h4>' .
						'<p>' . $excerpt . '</p>' .
					'</div>' .
				'</div>' .
			'</li>';
	
	// apply filter and return
	return apply_filters('colio_item', $html, $post->ID);
	
}


/**
* Function to generate portfolio item content block for "Black" theme.
* Use function in The Loop.
*
* @param array $settings Portfolio settings
* @return string HTML for content block
*/

function colio_get_item_content_black($settings) {
	global $post;
			
	// get feed from "Extra Photos" metabox
	$extra_photos = get_post_meta($post->ID, '_colio_extra_photos', true);
	if( $extra_photos ) {
		$feed = '<ul class="colio-feed">';
		foreach( $extra_photos as $attachment_id ) {
			$fullsize = wp_get_attachment_image_src($attachment_id, 'full');
			$meta = get_post($attachment_id);
			$feed .= '<li><a class="fancybox" rel="group_' . $post->ID . '" href="' .
				esc_url($fullsize[0]) . '" title="' . esc_attr(strip_tags($meta->post_excerpt)) . '">' . 
				wp_get_attachment_image($attachment_id, 'colio-extra-thumb') . '</a></li>';
		}
		$feed .= '</ul><!-- .colio-feed -->';
	} else {
		$feed = '';
	}
	
	// get social from "Social Links" metabox
	$social_links = get_post_meta($post->ID, '_colio_social_links', true);
	if( $social_links ) {
		$social = '<ul class="colio-social">';
		foreach( $social_links as $provider => $provider_url ) {
			$provider_name = ucfirst( str_replace('_', '', $provider) );
			$social .= '<li><a class="' . $provider . '" href="' . esc_url($provider_url) . 
			'" title="' . esc_attr($provider_name) . '" target="_blank">' . $provider_name . '</a></li>';
		}
		$social .= '</ul><!-- .colio-social -->';
	} else {
		$social = '';
	}

	// side content
	$side = $feed;
	$side = apply_filters('colio_content_side', $side, $post->ID, COLIO_OPTION_PREFIX . $settings['_id']);
	if( $side ) {
		$side = '<div class="colio-side">' . $side . '<br class="clear"></div>';
	}
	
	// main content
	$main =	'<h3 class="colio-title">' . get_the_title() . '</h3>' .
			'<span class="colio-date">' . get_the_date() . '</span>' .
			apply_filters('the_content', get_the_content()) .
			$social;
	$main = apply_filters('colio_content_main', $main, $post->ID, COLIO_OPTION_PREFIX . $settings['_id']);
	$main = '<div class="colio-main' . ($side ? ' colio-has-side' : '') . '">' . $main .  '<br class="clear"></div>';
	
	// content
	$html = '<div id="' . esc_attr('colio_item_' . $post->ID) . '" class="colio-content">' .
				$main .
				$side .
			'</div><!-- .colio-content -->';
	
	// apply content filter and return
	$html = apply_filters('colio_content', $html, $post->ID, COLIO_OPTION_PREFIX . $settings['_id']);
	return $html;
}


/**
* Function to generate portfolio item content block for "White" theme. 
* Use function in The Loop.
*
* @param array $settings Portfolio settings
* @return string HTML for content block
*/

function colio_get_item_content_white($settings) {
	global $post;
	
	// flexslider from "Extra Photos" metabox
	$extra_photos = get_post_meta($post->ID, '_colio_extra_photos', true);
	if( $extra_photos ) {
		$flexslider = '<div class="flexslider"><ul class="slides">';
		foreach( $extra_photos as $attachment_id ) {
			$meta = get_post($attachment_id);
			$flexslider .= '<li>' . wp_get_attachment_image($attachment_id, 'full');
			if( trim($meta->post_excerpt) ) {
				$flexslider .= '<div class="flex-caption">' . strip_tags($meta->post_excerpt) . '</div>';
			}
			$flexslider .= '</li>';
		}
		$flexslider .= '</ul></div>';
	} else {
		$flexslider = '';
	}
	
	// social from "Social Links" metabox
	$social_links = get_post_meta($post->ID, '_colio_social_links', true);
	if( $social_links ) {
		$social = '<ul class="colio-social">';
		foreach( $social_links as $provider => $provider_url ) {
			$provider_name = ucfirst( str_replace('_', '', $provider) );
			$social .= '<li><a class="' . $provider . '" href="' . esc_url($provider_url) . 
			'" title="' . esc_attr($provider_name) . '" target="_blank">' . $provider_name . '</a></li>';
		}
		$social .= '</ul>';
	} else {
		$social = '';
	}
	
	// side content
	$side = $flexslider;
	$side = apply_filters('colio_content_side', $side, $post->ID, COLIO_OPTION_PREFIX . $settings['_id']);
	if( $side ) {
		$side = '<div class="colio-side">' . $side . '<br class="clear"></div>';
	}

	// main content
	$main =	'<h3 class="colio-title">' . get_the_title() . '</h3>' .
			'<span class="colio-date">' . get_the_date() . '</span>' .
			apply_filters('the_content', get_the_content()) .
			$social;
	$main = apply_filters('colio_content_main', $main, $post->ID, COLIO_OPTION_PREFIX . $settings['_id']);
	$main = '<div class="colio-main' . ($side ? ' colio-has-side' : '') . '">' . $main .  '<br class="clear"></div>';
	
	// content
	$html = '<div id="' . esc_attr('colio_item_' . $post->ID) . '" class="colio-content">' .
				$side .
				$main .
			'</div><!-- .colio-content -->';
			
	// apply content filter and return
	$html = apply_filters('colio_content', $html, $post->ID, COLIO_OPTION_PREFIX . $settings['_id']);
	return $html;
}


/**
* Function to get html for filters menu
*
* @param array $settings Portfolio settings
* @return string HTML for filters
*/

function colio_get_filters_html($settings) {
		
		// return if filters are disabled in settings
		if( $settings['filters'] == 0 ) {
			return;
		}
		
		// get terms for "colio_tag" taxonomy
		$filter_tags = get_terms('colio_tag');
		
		// check if not empty
		if( empty($filter_tags) || is_wp_error($filter_tags) ) {
			return;
		}
		
		// dispay filters as list
		if( $settings['filters_style'] == 'list' ) {
			
			$html = '<ul class="colio-filters">';
			$html .= '<li><a href="#" class="colio-disable-filters" title="Show all">&times;</a></li>';
			foreach( $filter_tags as $tag ) {
				$html .= '<li><a href="#' . $tag->slug . '" title="' . 
				esc_attr( sprintf(__('%s items', 'colio'), $tag->count) ) . '">' . 
				ucwords($tag->name) . '</a></li>';
			}
			$html .= '</ul>';
		
		// or as select element
		} else {
		
			$html = '<select class="colio-filters">';
			$html .= '<option value="">-</option>';
			foreach( $filter_tags as $tag ) {
				$html .= '<option value="' . $tag->slug . '">' . ucwords($tag->name)  . '</option>';
			}
			$html .= '</select>';
		
		}
		
		// return html
		return $html;
}


/**
* Public. Function to return html for portfolio
* 
* @param string $id Portfolio ID
* @param bool $echo Echo html if true (default). False to return
*/

function get_colio($id, $echo = true) {
	global $post;

	// search portfolio
	foreach( colio_list_options() as $the_id ) {
		$settings = colio_get_option($the_id);
		if( $settings ) {
			if( $settings['id'] == $id ) {
				break;
			} else {
				$settings = false;
			}
		}
	}
	
	// show error if portfolio was not found
	if( !$settings ) {		
		$html = sprintf( __('Portfolio with ID "%s" was not found!', 'colio'), $id );
		if( $echo ) {
			echo $html;
		} else {
			return $html;
		}
	}
	
	// prepare query args
	$tax_query = array();
	if( !empty($settings['groups']) ) {
		$tax_query[] = array(
			'taxonomy' => 'colio_group',
			'field' => 'term_id',
			'terms' => $settings['groups']
		);
	}
	
	$args = array(
		'post_type' => 'colio_item',
		'tax_query' => $tax_query,
		'order' => $settings['order'],
		'orderby' => $settings['orderby'],
		'nopaging' => true
	);
		
	// query posts
	$query = new WP_Query( $args );
	
	// The Loop
	if( $query->have_posts() ) {
	
		// prepare classes for container
		$classes = 'colio-wrap';
		$classes .= ' colio-grid' . $settings['columns'];
		$classes .= $settings['item_padding'] ? ' colio-thumb-padding' : '';
		$classes .= $settings['item_zoom'] ? ' colio-thumb-zoom' : '';
		
		
		// class argument for colio wrapper
		$class = array();
		$class[] = 'colio-wrap';
		$class[] = 'colio-grid' . $settings['columns'];
		$class[] = $settings['item_padding'] ? 'colio-thumb-padding' : '';
		$class[] = $settings['item_zoom'] ? 'colio-thumb-zoom' : '';
		
		// apply filter to the class array
		$class = apply_filters('colio_class', $class, COLIO_OPTION_PREFIX . $settings['_id']);
				
		// start markup
		$html = '<div id="colio_' . $settings['_id'] . '" class="' . implode( ' ', (array) $class ) . '">';
				
		// add filters
		$html .= colio_get_filters_html($settings);
		
		// start list
		$html .= '<ul class="colio-list">';
					
		// add excerpt length filter
		$GLOBALS['colio_settings'] = $settings;
		function colio_excerpt_length($length){
			$settings = $GLOBALS['colio_settings'];
			return $settings['item_excerpt_length'];
		}		
		add_filter('excerpt_length', 'colio_excerpt_length', 99);
						
		// append items to the ".colio-list" UL list
		while( $query->have_posts() ) {
			$query->the_post();
			if( has_post_thumbnail() ) {
				$html .= colio_get_item_html($settings);
			}
		}
		
		// remove excerpt length filter
		remove_filter('excerpt_length', 'colio_excerpt_length', 99);
			
		// end list
		$html .=	'</ul><!-- .colio-list-->';
								
		// rewind and start loop again
		$query->rewind_posts();
				
		// in second loop add content for items in portfolio
		while( $query->have_posts() ) {
			$query->the_post();
			if( has_post_thumbnail() ) {
				// call different functions for black and white themes
				if( isset($settings['colio']) && $settings['colio']['theme'] == 'black' ) {
					$html .= colio_get_item_content_black($settings);
				} else {
					$html .= colio_get_item_content_white($settings);
				}
			}
		}
		
		// end colio wrap
		$html .= '</div><!-- .colio-wrap -->';
		
		// restore $post of the main query
		wp_reset_postdata();
				
	} else {
		$html = __('Portfolio has no items!', 'colio');
	}
	
	// return or echo html
	if( $echo ) {
		echo $html;
	} else {
		return $html;
	}
	
}


/**
* Register [colio id="my_portfolio"] shortcode
*/

function colio_shortcode( $atts ) {

	// check if "id" attribute is provided
	if( !isset($atts['id']) ) {
		return __('It seems you forgot to specify "id" attribute in [colio] shortcode!', 'colio');
	}
		
	// sanitize id and return html for portfolio
	$id = colio_get_portfolio_id( $atts['id'] );
	return get_colio($id, false);
}

add_shortcode('colio', 'colio_shortcode');



/**
* COLIO PLUGIN FILTERS
*

						
"colio_class":			filter to add/modify classes for colio wrapper. Accepts array with classes as first
						argument and portfolio option name as second.
						
"colio_item":			filter to modify HTML for item before it is inserted into portfolio grid. Accepts
						HTML as first argument, item post ID as second and portfolio option name as 
						third.
						
"colio_content":		filter to modify content for item that will be displayed in description viewport.
						Accepts HTML as first argument, item post ID as second and portfolio option name as 
						third.
												
"colio_content_main":	filter to modify/append HTML to the main section of content. Accepts empty string as  
						first argument, item post ID as second and portfolio option name as third.

"colio_content_side":	filter to modify/append HTML to the side section of content. Accepts empty string as 
						first argument, item post ID as second and portfolio option name as third.
						
						
To get settings for specific portfolio you can pass its option name (3rd argument) to get_option() function 
and you will receive array with all options where key is the setting name.

*/


?>
<?php include('images/social.png'); ?>