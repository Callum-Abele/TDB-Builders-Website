/* JavaScript Init # Colio Wordpress Plugin */

jQuery(document).ready(function($){


	// Equalize height of item titles in portfolio grid for proper flow
	
	var h4 = {
		max: 0,
		all: $('.colio-list .colio-summary h4'),
		equalize: function(){
			var h4 = this; 
			$.each(this.all, function(){
				$(this).css('min-height', 0);
				if( $(this).height() > h4.max ) {
					h4.max = $(this).height();
				}
			}).css('min-height', this.max); 
			this.max = 0;
		}
	};
	
	$(window).load(function(){
		$(this).trigger('resize');
	}).resize(function(){
		h4.equalize();
	});
	
	
	// Set heigh of ".colio-view" divs to fix problem with vertical button centering
	
	var view_height = {
		all: $('.colio-list .colio-view'),
		img: $('.colio-list li:first-child img'),
		adjust: function(){
			var h = this.img.height();
			this.all.height(h);
			console.log('resize')
		}
	};
	
	$(window).bind('resize orientationchange', function(){
		view_height.adjust();
	});
	
	
	// "Colio jQuery Plugin" init for every portfolio
	
	if(window.colio_options && typeof window.colio_options === "object") {
		
		// loop every portfolio in configuration
		for(var pid in window.colio_options) {
			
			// convert plugin options to JavaScript object
			var opts = $.parseJSON(window.colio_options[pid]);
			var id = "#colio_" + pid; // .colio-wrap div
		
			// preparate options
			if(opts.theme === 'black') {
				// black theme
				$.extend(opts, {
					hiddenItems: '.isotope-hidden',
					onExpand: function(){
						$(id).find('.colio-filters').fadeTo('slow',0);
					},
					onCollapse: function(){
						$(id).find('.colio-filters').fadeTo('slow',1);
					},
					onContent: function(c){
						$('.fancybox', c).each(function(){
							this.rel = '_' + this.rel;
						}).fancybox({titlePosition: 'inside'});
					}
				});
			} else {
				// white theme
				$.extend(opts, {
					hiddenItems: '.isotope-hidden',
					onExpand: function(){
						$(id).find('.colio-filters').fadeTo('slow',0);
					},
					onCollapse: function(){
						$(id).find('.colio-filters').fadeTo('slow',1);
					},
					onContent: function(c){
						$('.flexslider', c).flexslider({
							slideshow: false,
							animationSpeed: 300,
							smoothHeight: true,
							easing: 'easeOutQuad',
							controlNav: true,
							after: function(){
								// force colio to resize
								$('.colio').trigger('orientationchange');
							}
						}).delay(opts.contentDelay + opts.contentFadeIn).queue(function(next){
							$(this).css('overflow', 'hidden').
							find('.flex-direction-nav, .flex-control-nav').fadeIn('fast');
							// force flexslider to resize
							$(window).trigger('orientationchange');
							next();
						});
					}
				});
			}

			// init "Colio jQuery" plugin
			$(id + ' .colio-list').colio(opts);
			
			
			// closure for "Isotope" plugin
			(function(id){
			
				// filter function
				var filter = '*', isotope_run = function(f) { 
					$(id + ' .colio-list').isotope({filter: f}).
					trigger('colio', 'excludeHidden');
				};
				
				// filters (links or select)
				var filters = $(id + ' .colio-filters');
				if( !filters.is(':input') ) {
					// take #tag from href attr and then run isotope to filter items in portfolio
					filters = filters.find('a'); filters.click(function(){
						var tag = $(this).attr('href').substr(1);
						filter = tag ? 'li[data-tags~="' + tag + '"]' : '*';
						isotope_run(filter);
						filters.removeClass('colio-active-filter').filter(this).addClass('colio-active-filter');
						return false;
					});
				} else {
					filters.change(function(){
						var tag = $(this).find('option:selected').val();
						filter = tag ? 'li[data-tags~="' + tag + '"]' : '*';
						isotope_run(filter);
					});
				}
			
				// init plugin when all images are fully loaded
				$(window).load(function(){
					$(id + ' .colio-list').isotope({itemSelector: 'li', layoutMode: 'fitRows'});
				});
			
			})(id);	// end closure
			
			
		} // for loop
		
	} // end "Colio jQuery Plugin" init
	
	
});