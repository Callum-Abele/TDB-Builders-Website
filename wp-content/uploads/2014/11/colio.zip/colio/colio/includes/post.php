<?php 

/********************************************************************************

	All that is related to colio item post type, a post type for portfolio 
	items. Post type taxonomies as well as "Extra Photos" and "Social Links"
	metaboxes (v)

********************************************************************************/

/**
* Register colio item post type for portfolio items
*/

function colio_register_post_type(){
	
	$labels = array(
		'name' => _x('Items', 'plural name', 'colio'),
		'singular_name' => __('Item', 'colio'),
		'menu_name' => _x('Colio', 'plugin top menu', 'colio'),
		'name_admin_bar' => _x('Colio', 'admin bar', 'colio'),
		'all_items' => _x('Items', 'menu item', 'colio'),
		'add_new' => _x('New Item','menu item', 'colio'),
		'add_new_item' => __('New Item', 'colio'),
		'edit_item' => __('Edit Item', 'colio'),
		'new_item' => __('New Item', 'colio'),
		'view_item' => __('View Item', 'colio'),
		'search_items' => __('Search Items', 'colio'),
		'not_found' => __('No Items found.', 'colio'),
		'not_found_in_trash' => __('No Items found in Trash.', 'colio')
	);
	
	$args = array(
		'labels' => $labels,
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_admin_bar' => false,
		'show_in_nav_menus' => false,
		'menu_position' => null,
		'hierarchical' => false,
		'capability_type' => 'post',
		'menu_icon' => COLIO_PLUGIN_URL . 'backend/menu-icon.png',
		'supports' => array('title','editor','excerpt','thumbnail'),
		'taxonomies' => array('colio_group','colio_tag'),
		'publicly_queryable' => true,
		'query_var' => true
	);

	register_post_type('colio_item', $args);

}

add_action('init', 'colio_register_post_type');


/**
* Enable post thumbnails for colio post type, if not enabled by the theme
*/

function colio_enable_post_thumbnails(){
	if( !current_theme_supports('post-thumbnails') ) {
		add_theme_support( 'post-thumbnails', array('colio_item') );
	}
}

add_action('after_setup_theme', 'colio_enable_post_thumbnails');


/**
* Register group taxonomy to organize portfolio items
* into different groups and assign them to portfolios
*/

function colio_register_group_taxonomy(){

	$labels = array(
		'name'              => _x('Groups', 'plural name', 'colio'),
		'singular_name'     => __('Group', 'colio'),
		'search_items'      => __('Search Groups', 'colio'),
		'all_items'         => __('All Groups', 'colio'),
		'parent_item'       => __('Parent Group', 'colio'),
		'parent_item_colon' => __('Parent Group:', 'colio'),
		'edit_item'         => __('Edit Group', 'colio'),
		'update_item'       => __('Update Group', 'colio'),
		'add_new_item'      => __('Add Group', 'colio'),
		'new_item_name'     => __('New Group Name', 'colio'),
		'menu_name'         => _x('Groups', 'menu name', 'colio'),
	
	);

	$args = array(
		'hierarchical' => true,
		'labels' => $labels,
		'public' => true,
		'show_ui' => true,
		'show_in_nav_menus' => false,
		'show_tagcloud' => false,
		'publicly_queryable' => true,
		'query_var' => true
	);
	
	
	register_taxonomy('colio_group', array('colio_item'), $args);
}

add_action('init', 'colio_register_group_taxonomy');


/**
* Register tag taxonomy for making portfolio items filterable 
* and use with filters
*/

function colio_register_tag_taxonomy(){

	$labels = array(
		'name'              => _x('Filter Tags', 'plural name', 'colio'),
		'singular_name'     => __('Tag', 'colio'),
		'search_items'      => __('Search Tags', 'colio'),
		'all_items'         => __('All Tags', 'colio'),
		'parent_item'       => __('Parent Tag', 'colio'),
		'parent_item_colon' => __('Parent Tag:', 'colio'),
		'edit_item'         => __('Edit Tag', 'colio'),
		'update_item'       => __('Update Tag', 'colio'),
		'add_new_item'      => __('Add Tag', 'colio'),
		'new_item_name'     => __('New Tag Name', 'colio'),
		'menu_name'         => _x('Tags','menu item', 'colio'),
	
	);

	$args = array(
		'hierarchical' => false,
		'labels' => $labels,
		'public' => true,
		'show_ui' => true,
		'show_in_nav_menus' => false,
		'show_tagcloud' => false,
		'publicly_queryable' => true,
		'query_var' => true
	);
	
	
	register_taxonomy('colio_tag', array('colio_item'), $args);
}

add_action('init', 'colio_register_tag_taxonomy');


/** 
* Functino to add custom columns to colio item post type
*
* @param array $columns Array with column names
*/

function colio_post_manage_columns($columns){
	return array(
		'cb' => '<input type="checkbox" />',
		'title' => __('Title', 'colio'),
		'thumb' => __('Thumbnail', 'colio'),
		'group' => __('Groups', 'colio'),
		'date' => __('Date', 'colio')
	);		
}


/** 
* Function to output values for custom columns for colio item post type
*
* @param string $column_name Column
* @param int $post_id Colio item post ID
*/

function colio_post_custom_column($column_name, $post_id){
	switch($column_name) {
		case "thumb":
			if( has_post_thumbnail($post_id) ) {
				echo get_the_post_thumbnail($post_id, 'thumbnail');
			} else {
				echo '-';
			}			
		break;
		case "group":
			$groups = wp_get_post_terms($post_id, 'colio_group', array("fields" => "ids"));
			echo colio_get_portfolio_groups( $groups );
		break;
	}
}

add_filter('manage_colio_item_posts_columns', 'colio_post_manage_columns');
add_action('manage_colio_item_posts_custom_column', 'colio_post_custom_column', 10, 2);


/**
* Add "Extra Photos" and "Social Links" metaboxes to colio item post type
*/

function colio_post_add_meta_boxes(){
		add_meta_box('colio_extra_photos', __('Extra Photos', 'colio'), 'colio_post_output_extra_photos_metabox', 'colio_item');
		add_meta_box('colio_social_links', __('Social Links', 'colio'), 'colio_post_output_social_links_metabox', 'colio_item');
}

add_action('add_meta_boxes', 'colio_post_add_meta_boxes');


/**
* Filter to add "data-attachment" attribute to the images inserted 
* using "Media Uploader" into the "Extra Photos" metabox 
*
* @param string $html HTML
* @param int $id Attachment ID
*/

function colio_image_send_to_editor_filter($html, $id) {
	return preg_replace('/href="http/', 'data-attachment="' . $id . '" href="http', $html);
}

add_filter('image_send_to_editor', 'colio_image_send_to_editor_filter', 10, 2);


/**
* Function to output content for "Extra Photos" metabox
*
* @param object $post Post object
*/

function colio_post_output_extra_photos_metabox($post){
	?>
	
	<div class="colio-extra-photos">
		
		<?php wp_nonce_field(basename(__FILE__), '_colio_metabox_nonce'); ?>
		
		<?php 
			
			// display saved photos by their attachment IDs
			$extra_photos = get_post_meta($post->ID, '_colio_extra_photos', true);

			if( $extra_photos ) {
				foreach( $extra_photos as $attachment_id ) {
		?>
			<label>
				<input type="hidden" name="colio_extra_photos[]" value="<?php echo $attachment_id; ?>">
				<?php echo wp_get_attachment_image($attachment_id, 'colio-extra-thumb'); ?>
				<a href="#" class="colio-remove-photo" title="<?php _e('Remove photo','colio'); ?>">
				</a>
			</label>		
		<?php
				} 
			}
		?>
		
		<a href="#" class="colio-upload-photo" title="<?php _e('Upload photo', 'colio'); ?>"><span></span></a>
				
		<div class="clear"></div>
		
		<p class="description"><?php _e('Upload more photos to display in details for portfolio items. Drag photos to rearange them in desired order.', 'colio'); ?></p>
				
	</div> <!-- #colio-extra-photos -->
	
	<?php
}


/**
* Function to output content for "Social Links" metabox
*
* @param object $post Post object
*/

function colio_post_output_social_links_metabox($post){
	?>
	
		<div class="colio-social-links">
			
			<?php wp_nonce_field( basename(__FILE__), '_colio_metabox_nonce'); ?>
			
			<?php 
				
				// displayed saved social links
				$social_links = get_post_meta($post->ID, '_colio_social_links', true);
				
				if( $social_links ) {
					foreach( $social_links as $provider => $url ) {
						$provider_name = ucfirst( str_replace('_', '', $provider) );
						?>
						
						<p>
							<label>
								<span><?php echo $provider_name; ?></span>
								<input type="text" name="colio_social_links[<?php 
								echo esc_attr($provider); ?>]" value="<?php echo esc_url($url); ?>">
								<a href="#" class="colio-social-remove">Remove</a>
							</label>
						</p>
						
						<?php
					}
				}
			
			?>
						
			<div class="colio-social-select">
			
				<select id="colio_social_select">
					<?php
						
						// generate options for different social providers
						$providers = array('delicious', 'digg', 'dribble', 'ember', 'facebook', 
						'flickr', 'forrst', 'google', 'last_fm', 'linkedin', 'my_space', 'quora', 
						'rss', 'sharethis', 'skype', 'stumbleupon', 'tumblr', 'twitter', 'vimeo', 
						'you_tube');
						
						foreach( $providers as $provider ) {
							$provider_name = ucfirst( str_replace('_', '', $provider) );
							echo '<option value="' . $provider . '">' . $provider_name . '</option>';
						}
					
					?>
				</select>
				
				<input type="button" id="colio_social_add" class="button-secondary" value="<?php 
				echo esc_attr( __('Add Link','colio') ); ?>">
				
			</div> <!-- .colio-social-select -->
			
			<p class="description"><?php _e('Select social provider in dropdown list and click <strong>Add Link</strong> to enter URL', 'colio'); ?></p>
				
		</div><!-- .colio-social-links -->
	
	<?php	
}


/**
* Function to save "Extra Photos" and "Social Links" metaboxes 
* when post is updated
*
* @param int $post_id Post ID
*/

function colio_post_save_meta_boxes( $post_id ){
	
	// check if colio metabox nonce is set
	if( !isset($_POST['_colio_metabox_nonce']) ) {
		return;
	}

	// check if nonce is valid
	if( !wp_verify_nonce($_POST['_colio_metabox_nonce'], basename(__FILE__)) ) {
		return;
	}
	
	// check user capability
	if( !current_user_can('edit_post', $post_id) ) {
		return;
	}
	
	// prevent saving fields when WP is doing autosave
	if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
		return;
	}

	// sanitize "Extra Photos" metabox
	$extra_photos = array();
	if( isset($_POST['colio_extra_photos']) ) {
		foreach( $_POST['colio_extra_photos'] as $attachment_id ) {
			$extra_photos[] = intval($attachment_id);
		}
	}
	
	// sanitize "Social Links" metabox
	$social_links = array();
	if( isset($_POST['colio_social_links']) ) {
		foreach( $_POST['colio_social_links'] as $provider => $url ) {
			$social_links[$provider] = esc_url_raw($url);
		}
	}
	
	// save post meta
	update_post_meta($post_id, '_colio_extra_photos', $extra_photos);
	update_post_meta($post_id, '_colio_social_links', $social_links);
	
}

add_action('save_post', 'colio_post_save_meta_boxes');

?>