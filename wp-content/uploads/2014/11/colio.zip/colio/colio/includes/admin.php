<?php 

/********************************************************************************

	WP backend stuff - custom icons, styles and scripts for plugin admin

********************************************************************************/


/**
* Enqueue custom backend scripts & styles for plugin
*/

function colio_plugin_backend_scripts($page_hook){
	global $colio_settings_page;
	
	// colio settings page
	if( $page_hook == $colio_settings_page ) {
		wp_enqueue_script('wp-color-picker');
		wp_enqueue_style('wp-color-picker');
	}
	
	// post edit page
	if( $page_hook == 'post.php') {
		wp_enqueue_script('jquery-ui-sortable');
	}
	
	wp_register_script('jquery-easing', COLIO_PLUGIN_URL . 'jquery.easing.1.3.js', array('jquery'), '1.3', true);
	wp_enqueue_style('colio-admin', COLIO_PLUGIN_URL . 'backend/admin.css', array(), '1.0', 'screen');
	wp_enqueue_script('colio-admin', COLIO_PLUGIN_URL . 'backend/admin.js', array('jquery', 'jquery-easing'), '1.0', true);
}

add_action('admin_enqueue_scripts', 'colio_plugin_backend_scripts');


/**
* Prefix <h2> on colio item post page using :before (cheat)
*/

function colio_plugin_prefix_screen_title(){
	$screen = get_current_screen();
	if('edit-colio_item' == $screen->id || 'edit-colio_group' == $screen->id) {
		echo '<style type="text/css">';
		echo '#icon-edit + h2:before { content: "' . _x('Portfolio ', 'colio item screen prefix', 'colio'); '"; }';
		echo '</style>';
	}
}

add_action('admin_print_styles', 'colio_plugin_prefix_screen_title');


/**
* Run "colio_{action}" hooks when "?colio_action=" is present in URL
* of "Colio -> Settings" page. Hooked functions can accept one param 
* which is $_REQUEST array. Also they run with priority 5.
*/

function colio_settings_page_action_hook(){
	
	// can proceed only for colio settings page
	if( !isset($_GET['page']) || $_GET['page'] != 'colio_settings' ) {
		return;
	}
	
	// check if "?colio_action=" query string is present
	if( !isset($_REQUEST['colio_action']) ) {
		return;
	}
			
	// check cabability
	if( !current_user_can('manage_options') ) {
		wp_die(__('You do not have permissions to perform this action.', 'colio'));
	}
	
	// sanitize action and run hooked functions
	$action = sanitize_key($_REQUEST['colio_action']);
	if( $action != '' ) {
		do_action( 'colio_' . $action, $_REQUEST );
	}
 }

add_action('admin_init', 'colio_settings_page_action_hook', 5);


/**
* Hook to add new portfolio to the database with default settings
*
* @param array $args Array $_REQUEST 
*/

function colio_add_portfolio_action_handler( $args ) {
	
	// check nonce
	if( !wp_verify_nonce($args['_wpnonce'], basename(__FILE__)) ) {
		wp_die(__('You do not have permissions to perform this action.', 'colio'));
	}
	
	// check if portfolio name is set and get its ID
	if( isset($args['portfolio_name']) ) {
		$name = trim($args['portfolio_name']);
		$id = colio_get_portfolio_id($name);
		if( $id == '' ) {
			return;
		}
	} else {
		return;
	}
	
	// colio jquery plugin settings
	$colio_settings = array(
		'id' => 'colio_viewport_' . $id,		// colio "id" attribute for viewport
		'theme' => 'black',						// theme: black or white
		'theme_color' => '#ff5452',				// theme base color
		'placement' => 'before',				// viewport placement: before, inside or after
		'expand_duration' => 500,				// duration of expand animation, ms
		'expand_easing' =>'swing',				// easing for expand animation
		'collapse_duration' => 300,				// duration of collapse animation, ms
		'collapse_easing' => 'swing',			// easing for collapse animation
		'scroll_page' => true,					// whether to scroll page to viewport
		'scroll_duration' => 300,				// page scroll duration, ms
		'scroll_easing' => 'swing',				// page scroll easing
		'sync_scroll' => false,					// sync page scroll with expand/collapse of colio viewport
		'scroll_offset' => 10,					// page offset when colio viewport is expanded
		'content_fade_in' => 500,				// content fade-in duration, ms
		'content_fade_out' => 200,				// content fade-out duration, ms
		'content_delay' => 200,					// content fade-in delay on expand, ms
		'navigation' => true					// enable or disable next/previous navigation
	);
		
	// general settings
	$settings = array(
		'_id' => $id,							// ID (internal use only)
		'id' => $id,							// ID
		'name' => $name,						// name
		'columns' => 2,							// grid columns 2-3-4-5
		'filters' => 1,							// show filters ON/OFF
		'filters_style' => 'list',				// how to display filters: list or select
		'orderby' => 'post_date',				// how to order items: ID, date, etc
		'order' => 'DESC',						// order DESC or ASC
		'groups' => array(),					// one or few item groups to display in portfolio
		'item_margin' => 20,					// margin between adjacent items, px
		'item_padding' => 1,					// adds small padding around item thumbs
		'item_zoom' => 0,						// zoom thumb on hover with css3 transform
		'item_button_color' => '#ff5452', 		// color for "View Project" button
		'item_button_text' => 'View Project', 	// text for "View Project" button
		'item_hover_color' => '#000',			// item overlay color
		'item_hover_opacity' => 0.5,			// item overlay opacity
		'item_title_color' => '#444',			// item title color
		'item_title_hover_color' => '#999',		// item title hover color
		'item_title_font_size' => 14,			// item title font size
		'item_title_font' => 'inherit',			// item title font family
		'item_excerpt' => 1,					// show also item excerpt: ON/OFF
		'item_excerpt_length' => 10,			// show this many words in excerpt
		'item_excerpt_color' => '#999',			// excerpt text color
		'item_excerpt_font_size' => 12,			// smaller text for item excerpt
		'item_excerpt_font' => 'inherit',		// item excerpt font family
		'colio' => $colio_settings				// settings for Colio jQuery plugin
	);
	
	// save to db
	if( colio_add_option($id, $settings) ) {
		add_settings_error('colio_plugin_notice', 'colio_plugin',  __('Portfolio was successfully created!', 'colio'), 'updated');
	} else {
		add_settings_error('colio_plugin_notice', 'colio_plugin',  __('Portfolio with this ID already exist. Try another name!', 'colio'), 'error');
	}
	
}

add_action('colio_add_portfolio', 'colio_add_portfolio_action_handler');


/**
* Hook to remove portfolio settings from database
*
* @param array $args Array $_REQUEST 
*/


function colio_remove_portfolio_action_handler( $args ) {

	// check nonce
	if( !wp_verify_nonce($args['_wpnonce'], basename(__FILE__)) ) {
		wp_die(__('You do not have permissions to perform this action.', 'colio'));
	}
	
	// return if any of "id" or "confirm" are not set
	if( !isset($args['id'], $args['confirm']) ) {
		return;
	}
	
	// remove portfolio from db
	if( colio_remove_option( $args['id'] ) ) {
		add_settings_error('colio_plugin_notice', 'colio_plugin',  __('Portfolio was removed!', 'colio'), 'updated');
	}
}


add_action('colio_remove_portfolio', 'colio_remove_portfolio_action_handler');


/**
* Add "Settings" and "Help" pages to Colio menu. 
* Hook sufixes will be saved as global $colio_settings_page and $colio_help_page variables
*/

function colio_add_menu_pages(){	
	$GLOBALS['colio_settings_page'] = add_submenu_page( 'edit.php?post_type=colio_item', __('Settings', 'colio'), __('Settings', 'colio'), 'manage_options', 'colio_settings', 'colio_print_settings_page_content' );
	$GLOBALS['colio_help_page'] = add_submenu_page( 'edit.php?post_type=colio_item', __('Quick Help', 'colio'), __('Help', 'colio'), 'manage_options', 'colio_help', 'colio_print_help_page_content' );
}

add_action('admin_menu', 'colio_add_menu_pages');


/**
* Function to output "Settings" page content
*/

function colio_print_settings_page_content(){
?>

<div class="wrap">

	<div id="icon-edit" class="icon32 icon32-posts-colio_item"><br></div>
	<h2><?php _e('Portfolio Settings', 'colio'); ?></h2>
	
	<?php settings_errors('colio_plugin_notice'); ?>
		
	<p>
		<em>On this page you can manage portfolios for your website.
		<br>Need help? Click <a href="edit.php?post_type=colio_item&page=colio_help">here</a></em>
	</p>
	<br>
	
	<h3>Add Portfolio</h3>
	
	<p>To add new portfolio enter its name in field below and click <strong>Add New</strong> button</p>
							
	<form id="add_portfolio" method="post" action="">
	
		<input type="hidden" name="colio_action" value="add_portfolio">
		<?php wp_nonce_field( basename(__FILE__) ); ?>
		
		<input type="text" name="portfolio_name" value="" maxlength="18" placeholder="Portfolio Name" autofocus autocomplete="off">
		<input type="submit" name="submit" class="button-primary" value="Add New">
	
	</form>
	<br>
	
	<h3>Portfolio List</h3>
	
	<?php
		// check if we have portfolio in configuration
		if( !colio_list_options() ) :
			echo "<p>" . __('List empty.', 'colio') . "</p>";
		else :
	?>
			
	<!-- portfolio settings (ps) header -->
	
	<ul class="colio-ps-header colio-ps-grid">
		<li class="colio-ps-expand">&nbsp;</li>
		<li class="colio-ps-name"><?php _e('Portfolio Name', 'colio'); ?></li>
		<li class="colio-ps-shortcode"><?php _e('Shortcode', 'colio'); ?></li>
		<li class="colio-ps-group"><?php _e('Groups', 'colio'); ?></li>
		<li class="colio-ps-remove"><?php _e('Remove', 'colio'); ?></li>
	</ul>
	
	<!-- end ps header -->
	
	<?php
	
		endif;
		
		// loop portfolio IDs that we have in DB
		foreach( array_reverse( colio_list_options() ) as $id ) :
		
			// get portfolio settings (ps)
			$ps = colio_get_option($id);
			if( empty($ps) ) {
				continue;
			}
	?>
	
	<div class="colio-ps-section">
					
		<ul class="colio-ps-main colio-ps-grid">
			<li class="colio-ps-expand">
				<a href="#" title="<?php _e('Click to expand settings', 'colio'); ?>"><span></span></a>
			</li>
			<li class="colio-ps-name"><a href="#"><?php echo esc_html($ps['name']); ?></a></li>
			<li class="colio-ps-shortcode">
				<span class="colio-shortcode-text">[colio id=<?php echo esc_html('"' . $ps['id'] . '"'); ?>]</span>
				<span class="colio-help-icon" title="<?php
					_e('Copy and insert this shortcode into the page or post where you want portfolio to appear. To select shortcode simply click on it!', 'colio'); 
				?>"></span>
			</li>
			<li class="colio-ps-group"><?php echo colio_get_portfolio_groups( $ps['groups'], true ); ?></li>
			<li class="colio-ps-remove">				
				<form method="post" action="">
					<input type="hidden" name="colio_action" value="remove_portfolio">
					<input type="hidden" name="id" value="<?php echo $id; ?>">
					<?php wp_nonce_field( basename(__FILE__) ); ?>
					<input type="submit" name="submit" class="button-primary" value="Remove">
					<label>
						<input type="checkbox" name="confirm" value="1">
						<em><?php _e('Check to remove!', 'colio'); ?></em>
					</label>
				</form>
			</li>
		</ul><!-- #colio-ps-main -->
		
		<div class="colio-ps-content">
		
			<hgroup>
				<h3><?php echo esc_html($ps['name']); ?></h3>
				<h4><?php _e('Portfolio Settings', 'colio'); ?></h4>
			</hgroup>
						
			<form method="post" action="options.php">			
				<?php settings_fields('colio_settings_group_' . $id); ?>
				
				<?php

					// portfolio entry in wp_options will never change, so to keep track of it
					// and use it in register_settings's sanitize function, we add it as 
					// hidden "_id" input to the form (see includes/settings.php)
					
					$option = COLIO_OPTION_PREFIX . $id; 
					echo '<input type="hidden" name="' . $option . '[_id]" value="' . $id . '">';
					
					// also, because we display settings for all portfolios on the same page
					// we must use do_settings_fields() instead of settings_sections() as 
					// we have settings sections separately for every portfolio 
					// (see includes/settings.php) and they must be saved under their own 
					// entries in wp_options. I know, it's tricky but it works :)

				?>
				
				<!-- general settings -->
				<div class="colio-ps-tab">	
					<h3 class="title"><?php _e('General', 'colio'); ?></h3>
					<p class="description"><?php 
						_e('This tab has to do with portfolio grid and items settings.', 'colio'); ?>
					</p>
						
					<table class="form-table">
						<tbody>
							<?php do_settings_fields('colio_settings', 'colio_section_general_' . $id); ?>
						</tbody>
					</table>
					
				</div>
				<!-- #general settings -->
				
				<!-- details settings -->
				<div class="colio-ps-tab">
					<h3 class="title"><?php _e('Details Viewport', 'colio'); ?></h3>
					<p class="description"><?php 
						_e('In this tab you can configure expandable viewport with item details.', 'colio'); ?>
					</p>
					
					<table class="form-table">
						<tbody>
							<?php do_settings_fields('colio_settings', 'colio_section_details_' . $id); ?>
						</tbody>
					</table>
				</div>
				<!-- #details settings -->
				
				<div class="clear"></div>
				
				<p class="colio-ps-footer">
					<?php submit_button(__('Save Changes', 'colio'), 'primary', 'submit', false); ?> 
					<a href="#" class="colio-ps-cancel button-secondary"><?php _e('Cancel', 'colio'); ?></a>
				</p>
			
			</form><!-- #options.php -->
					
		</div><!-- #colio-ps-content -->
	
	</div><!-- #colio-ps-section -->
	
	<?php 
		endforeach; // end loop
	?>
	
	<div class="clear"></div>

</div> <!-- #wrap -->
	
<?php
}


/**
* Function to output "Help" page content
*/

function colio_print_help_page_content(){
?>

<div class="wrap colio-help-page">
	
	<div id="icon-edit" class="icon32 icon32-posts-colio_item"><br></div>
	<h2><?php _e('Quick Help', 'colio'); ?></h2>
	
	<p>
		<em>Below you will find step-by-step instructions to help you to get started with Colio plugin</em>
		<br><em>Full documentation about plugin is <a href="<?php echo COLIO_PLUGIN_DOCS; ?>" target="_blank">here</a></em>
	</p>
	
	<br>
	<h3>Creating your first portfolio</h3>
	
	<p>To create portfolio please follow the steps below:</p>
	
	<ol>
		<li>Start with adding portfolio items with <strong>Colio -> New Item</strong></li>
		<li>Enter title, content and featured image for every new item</li>
		<li>Then in <strong>Groups</strong> metabox add new group, let's say "My Group". We will use it 
			<br>later in portfolio settings</li>
		<li>Scroll page down to <strong>Extra Photos</strong> metabox and upload few additional photos
			<br>for item. They will be used to create a gallery that you will see in item details</li>
		<li>Also you can set social links for item in <strong>Social Links</strong> metabox</li>
		<li>Perform step 1 - 5 to add all items. And make sure they use same group - "My Group"</li>
		<li>Ok. Next go to <strong>Colio -> Settings</strong> and create your first portfolio</li>
		<li>Enter portfolio name and click <strong>Add New</strong> button</li>
		<li>Page will reload and your portfolio will appear in list</li>
		<li>Now click <strong>+</strong> icon to open settings</li>
		<li>In settings find <strong>Groups</strong> drop down list and select "My Group"</li>
		<li>Configure all other parameters and click <strong>Save Changes</strong></li>
		<li>Copy shortcode for your portfolio, that looks like <em>[colio id="my_portfolio"]</em></li>
		<li>Open page/post and insert shortcode where your portfolio should appear</li>
		<li>Reload page to take a look at your new portfolio!</li>
	</ol>
	
	<br>
	<h3>How to make portfolio filterable</h3>
	
	<p>Now it's time to learn how to make your portfolio filterable</p>
	
	<ol>
		<li>Making your portfolio filterable is very easy! All you need to do is click "Quick Edit" link for 
			<br> every item in <strong>Colio -> Items</strong> list and add tags into <strong>Filter Tags</strong> field</li>
		<li>When it's done, go to <strong>Colio -> Settings</strong> and click <strong>+</strong> to open settings</li>
		<li>Make sure that <strong>Filters</strong> checkbox is checked and select style to display filters in <strong>Filters Style</strong> option</li>
		<li>Now reload page with your portfolio again and you should see the filters</li>
		<li>Click them to see how they work</li>
		<li>If you want to remove filter, go to <strong>Colio -> Tags</strong> menu and simply remove corresponding tag</li>
	</ol>
	
	<br>
	<div class="clear"></div>
	
</div>

<?php
}


?>