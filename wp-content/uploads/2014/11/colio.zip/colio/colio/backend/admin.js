
// Colio Wordpress Plugin. Admin

jQuery(document).ready(function($){
	
	
	/* Colio -> Settings.
	==============================================================*/
	
	// check if name field is not empty when adding new portfolio
	$('#add_portfolio').submit(function(){
		return $(this).find('input:text').val() !== "";
	});
	
	// select all text on click
	$('.colio-shortcode-text').click(function(){
		if(document.body.createTextRange) { // ie
			var range = document.body.createTextRange();
			range.moveToElementText(this);
			range.select();			
		} else if(window.getSelection && document.createRange) { // other
			var selection = window.getSelection();
			var range = document.createRange();
			range.selectNodeContents(this);
			selection.removeAllRanges();
			selection.addRange(range);
		}	
	});
	
	// remove portfolio from list if "Check to remove!" is checked
	$('.colio-ps-main form').submit(function(){
		return $(this).find('input:checkbox').is(':checked');
	});
	
	// settings accordion for portfolio
	$('.colio-ps-expand > a, .colio-ps-name > a, a.colio-ps-cancel').click(function(e){
	
		// prevent default
		e.preventDefault();
	
		// find expanded and current sections
		var expanded = $('.colio-ps-expanded'), 
			current = $(this).closest('.colio-ps-section'),
			admin_bar = parseFloat($('html.wp-toolbar').css('padding-top')) || 0,
			easing = 'easeOutQuart';
		
		// collapse any expanded section, then expand current but only if it's not already expanded
		expanded.removeClass('colio-ps-expanded').find('.colio-ps-content').stop(true).slideUp(500, easing);
		if(current.get(0) !== expanded.get(0)) {
			current.addClass('colio-ps-expanded').find('.colio-ps-content').slideDown(300, easing, function(){
				$('body, html').stop().animate({'scrollTop': current.offset().top + admin_bar}, 500, easing);
			});
		}

	});
		
	//  init Iris color picker (available in WP 3.5+)
	if(typeof $.fn.wpColorPicker === 'function') {
		$('.colio-ps-color').wpColorPicker({palettes: false});
	}
	
	
	/* Colio -> Item. "Extra Photos" metabox 
	==============================================================*/
	
	// use jquery-ui-sortable plugin to rearange thumbs
	if(typeof $.fn.sortable === 'function') {
		$('.colio-extra-photos').sortable({
			items: '> label',
			placeholder: 'colio-sortable-spot',
			opacity: 0.8,
			cursor: 'move'
		});
	}
	
	// remove photos from list when ".colio-remove-photo" is clicked
	$('.colio-extra-photos').delegate('.colio-remove-photo', 'click', function(){
		$(this).parent().fadeOut(200, function(){
			$(this).remove();
		});
		return false;
	});
	
	// handle image insertion via "Media Upload" tickbox
	$('.colio-extra-photos .colio-upload-photo').click(function(){
	
		// show tickbox with post_id = 0 (not assign to any post)
		var url = 'media-upload.php?type=image&TB_iframe=1&post_id=0';
		tb_show('Upload Photo', url, false);
		
		// catch image url using send_to_editor handler
		var temp = window.send_to_editor;
		window.send_to_editor = function(html) {
		
			// get image src and attachment ID
			var src = $(html).find('img').attr('src');
			var attachment = $(html).filter('a').data('attachment');
			
			// insert markup after last thumb in list
			if(src && attachment) {
				var labels = $('.colio-extra-photos > label');
				var label = '<label>' + 
					'<input type="hidden" name="colio_extra_photos[]" value="' + attachment + '">' +
					'<img src="' + src + '" alt="">' +
					'<a href="#" class="colio-remove-photo" title="Remove photo"></a>' +
					'</label>';
				if(labels.length > 0) {
					labels.last().after(label);
				} else {
					$('.colio-extra-photos').prepend(label);
				}
			}

			// close thickbox and restore handler
			tb_remove();
			window.send_to_editor = temp;
			
		};
		
		// prevent default
		return false;
		
	});
	
	
	/* Colio -> Item. "Social Links" metabox 
	==============================================================*/
	
	// when "Add Link" is clicked add field to enter URL for social provider
	$('.colio-social-select #colio_social_add').click(function(){
	
		// metabox container
		var metabox = $('.colio-social-links');
	
		// get selected social provider from dropdown list
		var provider = metabox.find('#colio_social_select').val();
		var provider_name = metabox.find('#colio_social_select option[value="' + provider + '"]').text();
		var option = 'colio_social_links[' + provider + ']';
		
		// check if provider is not in use, in which case we move focus to it
		if( metabox.find('input[name="' + option + '"]').length ) {
			metabox.find('input[name="' + option + '"]').focus();
			return false;
		}
		
		// now add html for social provider
		var html = '<p><label>' +
						'<span>' + provider_name + '</span>' +
						'<input type="text" name="' + option + '" value="http://">' +
						'<a href="#" class="colio-social-remove">Remove</a>' + 
					'</label></p>';
							
		// add provider to document and change focus
		metabox.prepend(html).find('input[name="' + option + '"]').focus();
				
		// prevent default
		return false;
	});
	
	//  when "Remove" link is clicked remove social provider
	$('.colio-social-links').delegate('.colio-social-remove', 'click', function(){
		// remove paragraph with social provider
		$(this).closest('p').fadeOut(200, function(){ 
			$(this).remove(); 
		});
		return false;
	});
	
});

