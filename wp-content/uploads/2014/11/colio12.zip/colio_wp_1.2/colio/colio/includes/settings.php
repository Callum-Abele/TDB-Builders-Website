<?php 
/********************************************************************************

	Register settings for Colio -> Settings page using Wordpress "Settings API"

********************************************************************************/


/** 
* Function to register settings, add settings sections
* and fields
*/

function colio_register_settings(){

	// check if we have any portfolios
	if( !colio_list_options() ) {
		return;
	}
	
	// register settings for every portfolio so we can properly save things to wp_options
	foreach( colio_list_options() as $id ) {

		// define setting sections separate for every portfolio
		$general_section = 'colio_section_general_' . $id;
		$details_section = 'colio_section_details_' . $id;
	
		// add settings sections to the "colio_settings" page
		add_settings_section( $general_section, '', '', 'colio_settings' );
		add_settings_section( $details_section, '', '', 'colio_settings' );
		
		// add settings fields to the "General" section
		$general_fields = array(
			'id' => __('ID', 'colio'), 
			'name' => __('Name', 'colio'),
			'columns' => __('Columns', 'colio'),
			'filters' => __('Filters', 'colio'),
			'filters_style' => __('Filters Style','colio'),
			'orderby' => __('Order Items','colio'),
			'order' => __('Order', 'colio'),
			'groups' => __('Groups','colio'),
			'item_margin' => __('Item Margin','colio'),
			'item_padding' => __('Item Padding', 'colio'),
			'item_zoom' => __('Item Zoom', 'colio'),
			'item_button_text' => __('Item Button Text','colio'),
			'item_button_color' => __('Item Button Color','colio'),
			'item_hover_color' => __('Item Hover Color', 'colio'),
			'item_hover_opacity' => __('Item Hover Opacity','colio'),
			'item_title_color' => __('Item Title Color','colio'),
			'item_title_hover_color' => __('Item Title Hover Color','colio'),
			'item_title_font_size' => __('Item Title Font Size','colio'),
			'item_title_font' => __('Item Title Font','colio'),
			'item_excerpt' => __('Item Excerpt','colio'),
			'item_excerpt_length' => __('Item Excerpt Length','colio'),
			'item_excerpt_color' => __('Item Excerpt Color','colio'),
			'item_excerpt_font_size' => __('Item Excerpt Font Size','colio'),
			'item_excerpt_font' => __('Item Excerpt Font','colio'),
		);
		
		foreach( $general_fields as $key => $title) {
			add_settings_field( 'colio_' . $key, $title, 'colio_output_section_field_' . $key, 'colio_settings', $general_section, array('id' => $id, 'option' => COLIO_OPTION_PREFIX . $id, 's' => colio_get_option($id)) );
		}
		
		// add settings fields to "Details" section
		$details_fields = array(
			'theme' => __('Theme', 'colio'),
			'theme_color' => __('Theme Color', 'colio'),
			'placement' => __('Placement', 'colio'),
			'expand_duration' => __('Expand Duration', 'colio'),
			'expand_easing' => __('Expand Easing', 'colio'),
			'collapse_duration' => __('Collapse Duration', 'colio'),
			'collapse_easing' => __('Collapse Easing', 'colio'),
			'scroll_page' => __('Scroll Page', 'colio'),
			'scroll_duration' => __('Scroll Duration', 'colio'),
			'scroll_easing' => __('Scroll Easing', 'colio'),
			'sync_scroll' => __('Sync Scroll', 'colio'),
			'scroll_offset' => __('Scroll Offset', 'colio'),
			'content_fade_in' => __('Content Show Duration', 'colio'),
			'content_fade_out' => __('Content Hide Duration', 'colio'),
			'content_delay' => __('Content Show Delay', 'colio'),
			'navigation' => __('Navigation', 'colio'),
		);
		
		foreach( $details_fields as $key => $title) {
			$settings = colio_get_option($id);
			add_settings_field('colio_' . $key, $title, 'colio_output_section_field_' . $key, 'colio_settings', $details_section, array('id' => $id, 'option' => COLIO_OPTION_PREFIX . $id . '[colio]', 's' => $settings['colio']) );
		}

		// finally, register settings for portfolio
		register_setting( 'colio_settings_group_' . $id, COLIO_OPTION_PREFIX . $id, 'colio_sanitize_settings' );
	}

}

add_action('admin_init', 'colio_register_settings');


/**
* Function to sanitize input received from the form.
*
* @param array $input Array with form data, name as key
*/

function colio_sanitize_settings( $input ){

	// get old portfolio settings
	if( isset($input['_id']) ) {
		$old = colio_get_option($input['_id']);
	}
	
	// "_id" field missing or settings not exist
	if( !$old ) {
		wp_die(__('Cannot identify portfolio for saving.', 'colio'));
	}
	
	// colio js plugin new/old settings
	$old_colio = $old['colio'];
	$input_colio = $input['colio'];
		
	// sanitize name and make sure ID won't be empty
	if( isset($input['name']) ) {
		$name = sanitize_text_field($input['name']);
		if( '' == colio_get_portfolio_id($name) ) {
			$name = false;
		}
	}
	
	// sanitize color fields
	$color_input = array('item_hover_color', 'item_button_color', 'item_title_color', 'item_title_hover_color', 'item_excerpt_color', 'theme_color');
	foreach( $color_input as $f ) {
		if( isset($input[$f]) ) {
			$input[$f] = colio_sanitize_color($input[$f]);
		} 
		if( isset($input_colio[$f]) ) {
			$input_colio[$f] = colio_sanitize_color($input_colio[$f]);
		}
	}
	
	// sanitize opacity field (0.0 - 1.0)
	if( isset($input['item_hover_opacity']) ) {	
		$opacity = floatval($input['item_hover_opacity']);
		if($opacity > 0 && $opacity <= 1) {
			$input['item_hover_opacity'] = $opacity;
		} else {
			$input['item_hover_opacity'] = null;
		}
	}
	
	// sanitize font size
	$fontsize_input = array('item_title_font_size' => 14, 'item_excerpt_font_size' => 12);
	foreach( $fontsize_input as $f => $v) {
		if( isset($input[$f]) ) {
			$input[$f] = intval($input[$f]) > 0 ? intval($input[$f]) : $v;
		}
	}
	
	
	// colio jquery plugin setting	
	$clean_colio = array(
		'id' => 'colio_viewport_' . $input['_id'],
		'theme' => isset($input_colio['theme']) ? $input_colio['theme'] : $old_colio['theme'],
		'theme_color' =>  isset($input_colio['theme_color']) ? $input_colio['theme_color'] : $old_colio['theme_color'],
		'placement' => isset($input_colio['placement']) ? $input_colio['placement'] : $old_colio['placement'],
		'expand_duration' => isset($input_colio['expand_duration']) ? intval($input_colio['expand_duration']) : $old_colio['expand_duration'],
		'expand_easing' => isset($input_colio['expand_easing']) ? $input_colio['expand_easing'] : $old_colio['expand_easing'],
		'collapse_duration' => isset($input_colio['collapse_duration']) ? intval($input_colio['collapse_duration']) : $old_colio['collapse_duration'],
		'collapse_easing' => isset($input_colio['collapse_easing']) ? $input_colio['collapse_easing'] : $old_colio['collapse_easing'],
		'scroll_page' => isset($input_colio['scroll_page']) ? 1 : 0,
		'scroll_duration' => isset($input_colio['scroll_duration']) ? intval($input_colio['scroll_duration']) : $old_colio['scroll_duration'],
		'scroll_easing' => isset($input_colio['scroll_easing']) ? $input_colio['scroll_easing'] : $old_colio['scroll_easing'],
		'sync_scroll' => isset($input_colio['sync_scroll']) ? 1 : 0,
		'scroll_offset' => isset($input_colio['scroll_offset']) ? intval($input_colio['scroll_offset']) : $old_colio['scroll_offset'],
		'content_fade_in' => isset($input_colio['content_fade_in']) ? intval($input_colio['content_fade_in']) : $old_colio['content_fade_in'],
		'content_fade_out' => isset($input_colio['content_fade_out']) ? intval($input_colio['content_fade_out']) : $old_colio['content_fade_out'],
		'content_delay' => isset($input_colio['content_delay']) ? intval($input_colio['content_delay']) : $old_colio['content_delay'],
		'navigation' => isset($input_colio['navigation']) ? 1 : 0
	);
	

	// all settings
	$clean = array(
		'_id' => $input['_id'],
		'id' => $name ? colio_get_portfolio_id($name) : $old['id'],
		'name' => $name ? $name : $old['name'],
		'columns' => isset($input['columns']) ? intval($input['columns']) : $old['columns'],
		'filters' => isset($input['filters']) ? 1 : 0,
		'filters_style' => isset($input['filters_style']) ? $input['filters_style'] : $old['filters_style'],
		'orderby' => isset($input['orderby']) ? $input['orderby'] : $old['orderby'],
		'order' => isset($input['order']) ? $input['order'] : $old['order'],
		'groups' => isset($input['groups']) ? $input['groups'] : array(),
		'item_margin' => isset($input['item_margin']) ? intval($input['item_margin']) : $old['item_margin'],
		'item_padding' => isset($input['item_padding']) ? 1 : 0,
		'item_zoom' => isset($input['item_zoom']) ? 1 : 0,
		'item_button_color' => isset($input['item_button_color']) ? $input['item_button_color'] : $old['item_button_color'],
		'item_button_text' => isset($input['item_button_text']) ? sanitize_text_field($input['item_button_text']) : $old['item_button_text'],
		'item_hover_color' => isset($input['item_hover_color']) ? $input['item_hover_color'] : $old['item_hover_color'],
		'item_hover_opacity' => isset($input['item_hover_opacity']) ? $input['item_hover_opacity'] : $old['item_hover_opacity'],		
		'item_title_color' => isset($input['item_title_color']) ? $input['item_title_color'] : $old['item_title_color'],
		'item_title_hover_color' => isset($input['item_title_hover_color']) ? $input['item_title_hover_color'] : $old['item_title_hover_color'],
		'item_title_font_size' => isset($input['item_title_font_size']) ? $input['item_title_font_size'] : $old['item_title_font_size'],
		'item_title_font' => isset($input['item_title_font']) ? $input['item_title_font'] : $old['item_title_font'],
		'item_excerpt' => isset($input['item_excerpt']) ? 1 : 0,
		'item_excerpt_length' => isset($input['item_excerpt_length']) ? intval($input['item_excerpt_length']) : $old['item_excerpt_length'],
		'item_excerpt_color' => isset($input['item_excerpt_color']) ? $input['item_excerpt_color'] : $old['item_excerpt_color'],
		'item_excerpt_font_size' => isset($input['item_excerpt_font_size']) ? $input['item_excerpt_font_size'] : $old['item_excerpt_font_size'],
		'item_excerpt_font' => isset($input['item_excerpt_font']) ? $input['item_excerpt_font'] : $old['item_excerpt_font'],
		'colio' => $clean_colio
	);
	
	// display notice
	add_settings_error('colio_plugin_notice', 'colio_plugin', __('Portfolio settings updated!', 'colio'), 'updated');
				
	// return sanitized settings
	return $clean;
}


/**
* Function to sanitize hex color
*
* @param $color Hex value
* @return mixed Hex value or NULL if not valid
*/

function colio_sanitize_color($color) {
	if( !$color ) {
		return null;
	}	
	if( preg_match( '/^#([a-f0-9]{3}){1,3}$/', strtolower( trim( $color ) ) ) ) {
		return $color;
	} else {
		return null;
	}
}


/** 
* Functions to output contents of different settings fields for 
* "Global" settings section
*
* @param array $args Array with keys "id" - portfolio id, "option" - wp_options entry
*					 to save settings, "s" - settings for portfolio
*/

function colio_output_section_field_id( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_id" name="' . $option . '[id]" readonly value="' . $s['id'] . '">';
}

function colio_output_section_field_name( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_name" name="' . $option . '[name]" value="' . $s['name'] . '">';
	echo '<span class="colio-help-icon" title="' . 
	__('Renaming portfolio will require you to update shortcode that you use on your website!', 'colio') . '"></span>';
}

function colio_output_section_field_columns( $args ) {
	extract($args);
	
	$col_options = '';
	foreach( array(2,3,4,5) as $col ) {
		$col_options .= '<option value="' . $col . '" ' . selected($col, $s['columns'], false) . '>' . $col . '</option>';
	}
	
	// output input element
	echo '<select id="colio_columns" name="' . $option . '[columns]">' . $col_options . '</select>';
	echo '<p class="description">' . __('Number of columns for portfolio', 'colio') . '</p>';
}


function colio_output_section_field_filters( $args ) {
	extract($args);
	
	// output input element
	echo '<label><input type="checkbox" id="colio_filters" name="' . $option . '[filters]" value="1"' . 
	checked(1, $s['filters'], false) . '> ' . __('Enable', 'colio') . '</label>';
	echo '<span class="colio-help-icon" title="' . __('To use this feature you should assign tags to portfolio items', 'colio') . '"></span>';
	echo '<p class="description">' . __('Enable portfolio filters', 'colio') . '</p>';
}

function colio_output_section_field_filters_style( $args ) {
	extract($args);
	
	// output input element
	echo '<label><input type="radio" id="colio_filters_style1" name="' . $option . '[filters_style]" value="list" ' . 
	 checked('list', $s['filters_style'], false) . '> List</label>';
	echo '<label><input type="radio" id="colio_filters_style2" name="' . $option . '[filters_style]" value="select" ' . 
	 checked('select', $s['filters_style'], false) . '> Select</label>';
	echo '<p class="description">' . __('Display portfolio filters as list or as select box','colio') . '</p>';
}

function colio_output_section_field_orderby( $args ) {
	extract($args);

	$order_options = '';
	$order = array('none', 'ID', 'date', 'author', 'title', 'name', 'modified', 'rand');
	foreach( $order as $ord) {
		$order_options .= '<option value="' . $ord . '" ' . selected($ord, $s['orderby'], false) . '>' . 
		ucfirst($ord) . '</option>';
	}
	
	// output input element
	echo '<select id="colio_orderby" name="' . $option . '[orderby]">' . $order_options . '</select>';
	echo '<p class="description">' . __('Sort items in portfolio by parameter', 'colio') . '</p>';
}

function colio_output_section_field_order( $args ) {
	extract($args);
	
	// output input element
	echo '<select id="colio_order" name="' . $option . '[order]">';
	echo '<option value="DESC" ' . selected('DESC', $s['order'], false) . '>DESC</option>';
	echo '<option value="ASC" ' . selected('ASC', $s['order'], false) . '>ASC</option>';
	echo '</select>';
}


function colio_output_section_field_groups( $args ) {
	extract($args);
	$options = array();
	$groups = get_terms('colio_group', 'orderby=count&hide_empty=0');
	
	if( $groups && !is_wp_error($groups) ) {
		foreach( $groups as $group ) {
			$selected = selected(in_array($group->term_id, $s['groups']), true, false);
			$options[] = '<option value="' . $group->term_id . '" ' . $selected . '>' . esc_html($group->name) . '</option>';
		}
	} else {
		$options[] = '<option value="">&nbsp; - &nbsp;</option>';
	}
	
	// output input element
	echo '<select id="colio_groups" name="' . $option . '[groups][]" multiple>' . implode('', $options) . '</select>';
	echo '<p class="description">' . __('Select one or few item groups to show in portfolio', 'colio') . '</p>';
}

function colio_output_section_field_item_margin( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_item_margin" name="' . $option . '[item_margin]" value="' . 
	esc_attr($s['item_margin']) . '">';
	echo '<p class="description">' . __('Outer margin for items in grid', 'colio') . '</p>';
}

function colio_output_section_field_item_padding( $args ) {
	extract($args);
	
	// output input element
	echo '<label><input type="checkbox" id="colio_item_padding" name="' . $option . '[item_padding]" value="1" ' .
	checked(1, $s['item_padding'], false) . '> Enable</label>';
	echo '<p class="description">' . __('Add small padding around item thumbs', 'colio') . '</p>';
}

function colio_output_section_field_item_zoom( $args ) {
	extract($args);
	
	// output input element
	echo '<label><input type="checkbox" id="colio_item_zoom" name="' . $option . '[item_zoom]" value="1" ' .
	checked(1, $s['item_zoom'], false) . '> Enable</label>';
	echo '<p class="description">' . __('Whether to zoom item thumb on mouse hover', 'colio') . '</p>';
}

function colio_output_section_field_item_button_color( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_item_button_color" class="colio-ps-color" name="' . 
	$option . '[item_button_color]" value="' . $s['item_button_color'] . '" data-default-color="' .
	$s['item_button_color'] . '">';
}

function colio_output_section_field_item_button_text( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_item_button_text" name="' . $option . '[item_button_text]" value="' .
	esc_attr($s['item_button_text']) . '">';
}

function colio_output_section_field_item_hover_color( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_item_hover_color" class="colio-ps-color" name="' . 
	$option . '[item_hover_color]" value="' . $s['item_hover_color'] . '" data-default-color="' .
	$s['item_hover_color'] . '">';
	echo '<p class="description">' . __('Item thumb overlay color on mouse hover', 'colio') . '</p>';
}

function colio_output_section_field_item_hover_opacity( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_item_hover_opacity" name="' . $option . '[item_hover_opacity]" value="' .
	$s['item_hover_opacity'] . '">';
	echo '<p class="description")>' . __('Item thumb overlay opacity on mouse hover', 'colio') . '</p>';
}

function colio_output_section_field_item_title_color( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_item_title_color" class="colio-ps-color" name="' . 
	$option . '[item_title_color]" value="' . $s['item_title_color'] . '" data-default-color="' .
	$s['item_title_color'] . '">';
}

function colio_output_section_field_item_title_hover_color( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_item_title_hover_color" class="colio-ps-color" name="' . 
	$option . '[item_title_hover_color]" value="' . $s['item_title_hover_color'] . '" data-default-color="' .
	$s['item_title_hover_color'] . '">';
}

function colio_output_section_field_item_title_font_size( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_item_title_font_size" name="' . $option . '[item_title_font_size]" value="' .
	esc_attr($s['item_title_font_size']) . '">';
}

function colio_output_section_field_item_title_font( $args ) {
	extract($args);
	
	$font_options = '';
	$safe_fonts = array('inherit', 'Arial', 'Times New Roman', 'Georgia', 'Tahoma', 'Impact', 'Palatino Linotype', 'Century Gothic', 'Lucida Sans Unicode', 'Lucida Console', 'Verdana', 'Trebuchet MS', 'Courier New');
	foreach( $safe_fonts as $font) {
		$font_options .= '<option value="' . $font . '" ' . selected($font, $s['item_title_font'], false) . '>' . 
		$font . '</option>';
	}
	// output input element
	echo '<select id="colio_item_title_font" name="' . $option . '[item_title_font]">' . $font_options . '</select>';
}

function colio_output_section_field_item_excerpt( $args ) {
	extract($args);
	
	// output input element
	echo '<label><input type="checkbox" id="colio_item_excerpt" name="' . $option . '[item_excerpt]" value="1"' . 
	checked(1, $s['item_excerpt'], false) . '> ' . __('Show excerpt', 'colio') . '</label>';
}

function colio_output_section_field_item_excerpt_length( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_item_excerpt_length" name="' . $option . '[item_excerpt_length]" value="' .
	esc_attr($s['item_excerpt_length']) . '">';
	echo '<p class="description">' . __('Number of words in excerpt', 'colio') . '</p>';
}

function colio_output_section_field_item_excerpt_color( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_item_excerpt_color" class="colio-ps-color" name="' . 
	$option . '[item_excerpt_color]" value="' . $s['item_excerpt_color'] . '" data-default-color="' .
	$s['item_excerpt_color'] . '">';
}

function colio_output_section_field_item_excerpt_font_size( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_item_excerpt_font_size" name="' . $option . '[item_excerpt_font_size]" value="' .
	esc_attr($s['item_excerpt_font_size']) . '">';
}

function colio_output_section_field_item_excerpt_font( $args ) {
	extract($args);
	
	$font_options = '';
	$safe_fonts = array('inherit', 'Arial', 'Times New Roman', 'Georgia', 'Tahoma', 'Impact', 'Palatino Linotype', 'Century Gothic', 'Lucida Sans Unicode', 'Lucida Console', 'Verdana', 'Trebuchet MS', 'Courier New');
	foreach( $safe_fonts as $font) {
		$font_options .= '<option value="' . $font . '" ' . selected($font, $s['item_excerpt_font'], false) . '>' . 
		$font . '</option>';
	}
	// output input element
	echo '<select id="colio_item_excerpt_font" name="' . $option . '[item_excerpt_font]">' . $font_options . '</select>';
}


/** 
* Functions to output contents for different settings fields for 
* "Global" settings section
*
* @param array $args Array with current portfolio ID as "id" key
*/

function colio_output_section_field_theme( $args ) {
	extract($args);
	
	// output input element
	echo '<label><input type="radio" id="colio_theme1" name="' . $option . '[theme]" value="black" ' . 
		checked('black', $s['theme'], false) . '> '. _x('Black', 'theme option', 'colio') . '</label>';
	echo '<label><input type="radio" id="colio_theme2" name="' . $option . '[theme]" value="white" ' . 
		checked('white', $s['theme'], false) . '> '. _x('White', 'placement option', 'colio') . '</label>';
	echo '<p class="description">' . __('Item details theme', 'colio') . '</p>';
}

function colio_output_section_field_theme_color( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_theme_color" class="colio-ps-color" name="' . 
	$option . '[theme_color]" value="' . $s['theme_color'] . '" data-default-color="' .
	$s['theme_color'] . '">';
	echo '<p class="description">' . __('Select base color for a theme', 'colio') . '</p>';
}

function colio_output_section_field_placement( $args ) {
	extract($args);
	
	// output input element
	echo '<label><input type="radio" id="colio_placement1" name="' . $option . '[placement]" value="before" ' . 
		checked('before', $s['placement'], false) . '> '. _x('Before', 'placement option', 'colio') . '</label>';
	echo '<label><input type="radio" id="colio_placement2" name="' . $option . '[placement]" value="inside" ' . 
		checked('inside', $s['placement'], false) . '> '. _x('Inside', 'placement option', 'colio') . '</label>';
	echo '<label><input type="radio" id="colio_placement3" name="' . $option . '[placement]" value="after" ' . 
		checked('after', $s['placement'], false) . '> '. _x('After', 'placement option', 'colio') . '</label>';
	echo '<p class="description">' . __('Item details placement, relative to the portfolio grid', 'colio') . '</p>';
}

function colio_output_section_field_expand_duration( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_expand_duration" name="' . $option . '[expand_duration]" value="' . 
	esc_attr($s['expand_duration']) . '">';
	echo '<p class="description">' . __('Details viewport expand duration, ms', 'colio') . '</p>';
}

function colio_output_section_field_expand_easing( $args ) {
	extract($args);
	
	// output input element
	$easing = array(
		'swing', 'linear', 
		'easeInQuad', 'easeOutQuad', 'easeInOutQuad',
		'easeInCubic', 'easeOutCubic', 'easeInOutCubic',
		'easeInQuart', 'easeOutQuart', 'easeInOutQuart', 
		'easeInQuint', 'easeOutQuint', 'easeInOutQuint', 
		'easeInSine', 'easeOutSine', 'easeInOutSine', 
		'easeInExpo', 'easeOutExpo', 'easeInOutExpo', 
		'easeInCirc', 'easeOutCirc', 'easeInOutCirc', 
		'easeInBack', 'easeOutBack', 'easeInOutBack'
	);
	
	$options = '';
	foreach( $easing as $e ) {
		$options .= '<option value="' . $e . '" ' . selected($e, $s['expand_easing'], false) . '>' . $e . '</option>';
	}
	
	echo '<select id="colio_expand_easing" name="' . $option . '[expand_easing]">' . $options . '</select>';
	echo '<p class="description">' . __('Details viewport expand easing', 'colio') . '</p>';
}

function colio_output_section_field_collapse_duration( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_collapse_duration" name="' . $option . '[collapse_duration]" value="' . 
	esc_attr($s['collapse_duration']) . '">';
	echo '<p class="description">' . __('Details viewport collapse duration, ms', 'colio') . '</p>';
}

function colio_output_section_field_collapse_easing( $args ) {
	extract($args);
	
	// output input element
	$easing = array(
		'swing', 'linear', 
		'easeInQuad', 'easeOutQuad', 'easeInOutQuad',
		'easeInCubic', 'easeOutCubic', 'easeInOutCubic',
		'easeInQuart', 'easeOutQuart', 'easeInOutQuart', 
		'easeInQuint', 'easeOutQuint', 'easeInOutQuint', 
		'easeInSine', 'easeOutSine', 'easeInOutSine', 
		'easeInExpo', 'easeOutExpo', 'easeInOutExpo', 
		'easeInCirc', 'easeOutCirc', 'easeInOutCirc', 
		'easeInBack', 'easeOutBack', 'easeInOutBack'
	);
	
	$options = '';
	foreach( $easing as $e ) {
		$options .= '<option value="' . $e . '" ' . selected($e, $s['collapse_easing'], false) . '>' . $e . '</option>';
	}
	
	echo '<select id="colio_collapse_easing" name="' . $option . '[collapse_easing]">' . $options . '</select>';
	echo '<p class="description">' . __('Details viewport collapse easing', 'colio') . '</p>';
}



function colio_output_section_field_scroll_page( $args ) {
	extract($args);
	
	// output input element
	echo '<label><input type="checkbox" id="colio_scroll_page" name="' . $option . '[scroll_page]" value="1" ' . 
	checked(1, $s['scroll_page'], false) . '> ' . __('Enable', 'colio') . '</label>';
	echo '<p class="description">' . __('Automatically scroll page to description viewport on expand', 'colio') . '</p>';
}

function colio_output_section_field_scroll_duration( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_scroll_duration" name="' . $option . '[scroll_duration]" value="' . 
	esc_attr($s['scroll_duration']) . '">';
	echo '<p class="description">' . __('Duration for page scroll, ms', 'colio') . '</p>';
}

function colio_output_section_field_scroll_easing( $args ) {
	extract($args);
	
	// output input element
	$easing = array(
		'swing', 'linear', 
		'easeInQuad', 'easeOutQuad', 'easeInOutQuad',
		'easeInCubic', 'easeOutCubic', 'easeInOutCubic',
		'easeInQuart', 'easeOutQuart', 'easeInOutQuart', 
		'easeInQuint', 'easeOutQuint', 'easeInOutQuint', 
		'easeInSine', 'easeOutSine', 'easeInOutSine', 
		'easeInExpo', 'easeOutExpo', 'easeInOutExpo', 
		'easeInCirc', 'easeOutCirc', 'easeInOutCirc', 
		'easeInBack', 'easeOutBack', 'easeInOutBack'
	);
	
	$options = '';
	foreach( $easing as $e ) {
		$options .= '<option value="' . $e . '" ' . selected($e, $s['scroll_easing'], false) . '>' . $e . '</option>';
	}
	
	echo '<select id="colio_scroll_easing" name="' . $option . '[scroll_easing]">' . $options . '</select>';
	echo '<p class="description">' . __('Easing for page scroll', 'colio') . '</p>';
}

function colio_output_section_field_sync_scroll( $args ) {
	extract($args);
	
	// output input element
	echo '<label><input type="checkbox" id="colio_sync_scroll" name="' . $option . '[sync_scroll]" value="1" ' . 
	checked(1, $s['sync_scroll'], false) . '> ' . __('Enable', 'colio') . '</label>';
	echo '<p class="description">' . __('Sync page scroll with expand/collapse of description viewport', 'colio') . '</p>';
}

function colio_output_section_field_scroll_offset( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_scroll_offset" name="' . $option . '[scroll_offset]" value="' . 
	esc_attr($s['scroll_offset']) . '">';
	echo '<p class="description">' . __('Description viewport offset from the top of page when it\'s expanded, px', 'colio') . '</p>';
}

function colio_output_section_field_content_fade_in( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_content_fade_in" name="' . $option . '[content_fade_in]" value="' . 
	esc_attr($s['content_fade_in']) . '">';
	echo '<p class="description">' . __('Content fade in duration, ms', 'colio') . '</p>';
}

function colio_output_section_field_content_fade_out( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_content_fade_out" name="' . $option . '[content_fade_out]" value="' . 
	esc_attr($s['content_fade_out']) . '">';
	echo '<p class="description">' . __('Content fade out duration, ms', 'colio') . '</p>';

}

function colio_output_section_field_content_delay( $args ) {
	extract($args);
	
	// output input element
	echo '<input type="text" id="colio_content_delay" name="' . $option . '[content_delay]" value="' . 
	esc_attr($s['content_delay']) . '">';
	echo '<p class="description">' . __('Content fade in delay, ms', 'colio') . '</p>';
}

function colio_output_section_field_navigation( $args ) {
	extract($args);
	
	// output input element
	echo '<label><input type="checkbox" id="colio_navigation" name="' . $option . '[navigation]" value="1" ' . 
	checked(1, $s['navigation'], false) . '> ' . __('Enable navigation', 'colio') . '</label>';
	echo '<p class="description">' . __('Enable next/prev controls inside description viewport', 'colio') . '</p>';
}


?>