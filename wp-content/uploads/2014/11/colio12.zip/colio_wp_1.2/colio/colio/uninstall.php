<?php

if ( !defined( 'WP_UNINSTALL_PLUGIN' ) ) 
    exit();
    
require(plugin_dir_path(__FILE__) . 'includes/options.php');

// delete all settings from DB
foreach(colio_list_options() as $option) {
	colio_remove_option($option);
}

// also remove list
delete_option(COLIO_OPTION_LIST);

?>